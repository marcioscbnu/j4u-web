"use client";

import { useCallback, useEffect, useState } from "react";
import {
  ADMIN_EMAIL,
  garantirConfiguracaoSupabase,
  supabase,
} from "@/lib/supabaseClient";

interface AdminAuthGuardProps {
  children: React.ReactNode;
}

export function AdminAuthGuard({ children }: AdminAuthGuardProps) {
  const [verificandoSessao, setVerificandoSessao] = useState(true);
  const [autorizado, setAutorizado] = useState(false);
  const [etapa, setEtapa] = useState<"enviar" | "verificar">("enviar");
  const [codigoOtp, setCodigoOtp] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [mensagem, setMensagem] = useState<string | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  const avaliarUsuario = useCallback((email?: string | null) => {
    const ok = email?.trim().toLowerCase() === ADMIN_EMAIL;
    setAutorizado(ok);
    if (!ok && email) {
      setErro("Acesso restrito à conta autorizada do administrador.");
    }
  }, []);

  useEffect(() => {
    let ativo = true;

    async function checarSessaoInicial() {
      try {
        garantirConfiguracaoSupabase();
        const { data, error } = await supabase.auth.getSession();
        if (!ativo) return;
        if (error) {
          setErro(error.message);
          setAutorizado(false);
        } else {
          avaliarUsuario(data.session?.user?.email);
        }
      } catch (err: unknown) {
        if (!ativo) return;
        setErro(
          err instanceof Error ? err.message : "Erro ao verificar sessão."
        );
      } finally {
        if (ativo) setVerificandoSessao(false);
      }
    }

    checarSessaoInicial();

    const { data: listener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        if (!ativo) return;
        avaliarUsuario(session?.user?.email);
        setVerificandoSessao(false);
      }
    );

    return () => {
      ativo = false;
      listener.subscription.unsubscribe();
    };
  }, [avaliarUsuario]);

  async function handleEnviarOtp(e: React.FormEvent) {
    e.preventDefault();
    setEnviando(true);
    setErro(null);
    setMensagem(null);

    try {
      garantirConfiguracaoSupabase();
      const { error } = await supabase.auth.signInWithOtp({
        email: ADMIN_EMAIL,
        options: {
          shouldCreateUser: false,
        },
      });

      if (error) throw error;

      setEtapa("verificar");
      setMensagem(
        `Código de verificação enviado para ${ADMIN_EMAIL}. Confira sua caixa de entrada.`
      );
    } catch (err: unknown) {
      setErro(
        err instanceof Error
          ? err.message
          : "Não foi possível enviar o código OTP."
      );
    } finally {
      setEnviando(false);
    }
  }

  async function handleVerificarOtp(e: React.FormEvent) {
    e.preventDefault();
    setEnviando(true);
    setErro(null);
    setMensagem(null);

    try {
      garantirConfiguracaoSupabase();
      const { data, error } = await supabase.auth.verifyOtp({
        email: ADMIN_EMAIL,
        token: codigoOtp.trim(),
        type: "email",
      });

      if (error) throw error;

      avaliarUsuario(data.user?.email ?? data.session?.user?.email);
    } catch (err: unknown) {
      setErro(
        err instanceof Error ? err.message : "Código OTP inválido ou expirado."
      );
    } finally {
      setEnviando(false);
    }
  }

  if (verificandoSessao) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <p className="text-sm font-medium text-slate-600">
          Verificando acesso administrativo...
        </p>
      </div>
    );
  }

  if (autorizado) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-3xl bg-white/95 backdrop-blur-xs border border-violet-200 p-7 shadow-md space-y-5">
        <div className="space-y-1.5">
          <span className="inline-block text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-900 border border-rose-200">
            Segurança OTP
          </span>
          <h1 className="text-xl font-bold text-slate-800">
            Acesso Restrito — J4UMarketPlace
          </h1>
          <p className="text-sm text-slate-600">
            Autenticação via código OTP para{" "}
            <span className="text-slate-800 font-semibold">{ADMIN_EMAIL}</span>.
          </p>
        </div>

        {etapa === "enviar" ? (
          <form onSubmit={handleEnviarOtp} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                E-mail autorizado
              </label>
              <input
                type="email"
                readOnly
                value={ADMIN_EMAIL}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={enviando}
              className="w-full py-2.5 px-4 rounded-xl bg-sky-200 hover:bg-sky-300/90 border border-sky-300 font-bold text-sm text-sky-950 disabled:opacity-50 transition"
            >
              {enviando ? "Enviando código..." : "Enviar código OTP"}
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerificarOtp} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Código OTP recebido por e-mail
              </label>
              <input
                type="text"
                inputMode="numeric"
                required
                value={codigoOtp}
                onChange={(e) => setCodigoOtp(e.target.value)}
                placeholder="Digite o código"
                className="w-full px-3.5 py-2.5 rounded-xl bg-violet-50/40 border border-violet-200 text-slate-800 text-sm focus:outline-none focus:bg-white focus:border-violet-400"
              />
            </div>

            <div className="flex gap-2.5">
              <button
                type="submit"
                disabled={enviando}
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-200 hover:bg-emerald-300/90 border border-emerald-300 font-bold text-sm text-emerald-950 disabled:opacity-50 transition"
              >
                {enviando ? "Validando..." : "Confirmar código"}
              </button>

              <button
                type="button"
                onClick={() => {
                  setEtapa("enviar");
                  setCodigoOtp("");
                  setErro(null);
                }}
                className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 hover:bg-slate-100"
              >
                Reenviar
              </button>
            </div>
          </form>
        )}

        {mensagem && (
          <p className="text-sm font-medium text-emerald-700">{mensagem}</p>
        )}
        {erro && <p className="text-sm font-medium text-rose-700">{erro}</p>}
      </div>
    </div>
  );
}
