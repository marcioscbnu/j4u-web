# J4UMarketPlace — Versão 4.3 (Compatibilidade Total + Categorias + Mockup Smartphone)

- **Compatibilidade total com bancos legados e novos:** Envia e normaliza simultaneamente os campos atuais (`fornecedor_id`, `categoria_id`, `url_afiliado`, `imagem_url`, `legenda_video`) e os campos legados (`fornecedor`, `url`, `cta`, `imagem`) sem falhar se alguma coluna ainda não existir ou possuir restrição `NOT NULL`.
- **Navegação completa por Categorias:** Tabela `categorias` no Supabase, filtro na vitrine com contagem dinâmica e CRUD completo no `/admin`.
- **Vitrine em preto puro (`#000000`):** Foto do produto exibida na íntegra (`object-contain`, sem cortes), badge de fornecedor e etiqueta de categoria.
- **Mockup interativo de smartphone (`Ver em vídeo`):**
  1. Exibir / ocultar legendas (CC)
  2. Adicionar / editar / remover legendas pelo teclado QWERTY virtual do smartphone
  3. Player vertical com barra de progresso (`seek`) e navegação entre ofertas
  4. Play / Pause (no player, clique na tela, botão lateral e barra de espaço)
  5. Mudo / Som
- **Painel Administrativo (`/admin`):** Protegido por OTP exclusivo para `j4umarketplace@gmail.com`.

## Atualização Rápida

1. Substitua a pasta `src/` do seu projeto pela pasta `src/` deste pacote (e atualize `supabase/schema.sql` se quiser manter o repositório sincronizado).
2. Rode `npm run build` para validar a compilação.
