import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "J4UMarketPlace — Vitrine Inteligente de Ofertas",
  description:
    "Curadoria diária por categorias e parceiros com visualização completa do produto e demonstração interativa em vídeo.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="dark bg-black">
      <body className="min-h-screen bg-black text-white antialiased selection:bg-blue-600 selection:text-white">
        {children}
      </body>
    </html>
  );
}
