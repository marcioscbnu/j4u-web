"use client";

import { useState } from "react";
import Link from "next/link";
import { AdminAuthGuard } from "@/components/AdminAuthGuard";
import { GerenciarOfertasAdmin } from "@/components/GerenciarOfertasAdmin";
import { GerenciarFornecedoresAdmin } from "@/components/GerenciarFornecedoresAdmin";
import { GerenciarCategoriasAdmin } from "@/components/GerenciarCategoriasAdmin";

export default function AdminPage() {
  const [versaoTaxonomias, setVersaoTaxonomias] = useState(0);

  return (
    <AdminAuthGuard>
      <main className="min-h-screen bg-black text-white px-4 py-8 max-w-6xl mx-auto space-y-8">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-800 pb-5">
          <div className="space-y-1">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Painel Administrativo — J4UMarketPlace
            </h1>
            <p className="text-sm text-zinc-400">
              Gestão de categorias, fornecedores, fotos na íntegra e vídeos
              locais (<code className="text-zinc-300">/video/video0001.mp4</code>)
              com legendas.
            </p>
          </div>

          <Link
            href="/"
            className="px-4 py-2 rounded-lg border border-zinc-700 bg-zinc-950 hover:bg-zinc-900 text-xs font-semibold text-zinc-200 transition"
          >
            Ver Vitrine Pública →
          </Link>
        </header>

        <GerenciarCategoriasAdmin
          onCategoriasAlteradas={() =>
            setVersaoTaxonomias((prev) => prev + 1)
          }
        />

        <GerenciarFornecedoresAdmin
          onFornecedoresAlterados={() =>
            setVersaoTaxonomias((prev) => prev + 1)
          }
        />

        <GerenciarOfertasAdmin key={versaoTaxonomias} />
      </main>
    </AdminAuthGuard>
  );
}
