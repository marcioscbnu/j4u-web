"use client";

import { useEffect, useMemo, useState } from "react";
import { Categoria, Fornecedor, Oferta } from "@/types/marketplace";
import {
  listarCategoriasVitrine,
  listarFornecedoresVitrine,
  listarOfertasVitrine,
} from "@/services/vitrineService";
import { SmartphoneVideoModal } from "@/components/SmartphoneVideoModal";

export type TipoOrdenacaoOferta =
  | "mais_recentes"
  | "menor_preco"
  | "maior_preco";

const ITENS_POR_PAGINA = 6;

function normalizarTexto(texto: string): string {
  return texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

export function VitrineJ4U() {
  const [ofertas, setOfertas] = useState<Oferta[]>([]);
  const [fornecedores, setFornecedores] = useState<Fornecedor[]>([]);
  const [categorias, setCategorias] = useState<Categoria[]>([]);

  const [categoriaSelecionada, setCategoriaSelecionada] =
    useState<string>("todas");
  const [fornecedorSelecionado, setFornecedorSelecionado] =
    useState<string>("todos");
  const [buscaTitulo, setBuscaTitulo] = useState<string>("");
  const [ordenacao, setOrdenacao] =
    useState<TipoOrdenacaoOferta>("mais_recentes");
  const [limiteVisivel, setLimiteVisivel] = useState<number>(ITENS_POR_PAGINA);
  const [indiceModalVideo, setIndiceModalVideo] = useState<number | null>(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    async function carregarVitrine() {
      setCarregando(true);
      setErro(null);
      try {
        const [listaOfertas, listaFornecedores, listaCategorias] =
          await Promise.all([
            listarOfertasVitrine(),
            listarFornecedoresVitrine(),
            listarCategoriasVitrine(),
          ]);
        setOfertas(listaOfertas);
        setFornecedores(listaFornecedores);
        setCategorias(listaCategorias);
      } catch (err: unknown) {
        setErro(
          err instanceof Error
            ? err.message
            : "Não foi possível carregar as ofertas."
        );
      } finally {
        setCarregando(false);
      }
    }

    carregarVitrine();
  }, []);

  useEffect(() => {
    setLimiteVisivel(ITENS_POR_PAGINA);
  }, [categoriaSelecionada, fornecedorSelecionado, buscaTitulo, ordenacao]);

  const categoriaAtivaObjeto = useMemo(() => {
    if (categoriaSelecionada === "todas") return null;
    return categorias.find((c) => c.id === categoriaSelecionada) ?? null;
  }, [categorias, categoriaSelecionada]);

  const fornecedorAtivoObjeto = useMemo(() => {
    if (fornecedorSelecionado === "todos") return null;
    return (
      fornecedores.find((f) => f.id === fornecedorSelecionado) ?? null
    );
  }, [fornecedores, fornecedorSelecionado]);

  const ofertasFiltradasEOrdenadas = useMemo(() => {
    const termo = normalizarTexto(buscaTitulo);

    const filtradas = ofertas.filter((oferta) => {
      const bateCategoria =
        categoriaSelecionada === "todas" ||
        oferta.categoria_id === categoriaSelecionada;

      const bateFornecedor =
        fornecedorSelecionado === "todos" ||
        oferta.fornecedor_id === fornecedorSelecionado;

      const bateTitulo =
        termo === "" || normalizarTexto(oferta.titulo ?? "").includes(termo);

      return bateCategoria && bateFornecedor && bateTitulo;
    });

    const copia = [...filtradas];

    copia.sort((a, b) => {
      if (ordenacao === "menor_preco") {
        return Number(a.preco ?? 0) - Number(b.preco ?? 0);
      }

      if (ordenacao === "maior_preco") {
        return Number(b.preco ?? 0) - Number(a.preco ?? 0);
      }

      const dataA = a.criado_em ? new Date(a.criado_em).getTime() : 0;
      const dataB = b.criado_em ? new Date(b.criado_em).getTime() : 0;
      return dataB - dataA;
    });

    return copia;
  }, [
    ofertas,
    categoriaSelecionada,
    fornecedorSelecionado,
    buscaTitulo,
    ordenacao,
  ]);

  const ofertasVisiveis = useMemo(() => {
    return ofertasFiltradasEOrdenadas.slice(0, limiteVisivel);
  }, [ofertasFiltradasEOrdenadas, limiteVisivel]);

  const ofertaSelecionadaVideo =
    indiceModalVideo !== null
      ? ofertasFiltradasEOrdenadas[indiceModalVideo] ?? null
      : null;

  const totalFiltrado = ofertasFiltradasEOrdenadas.length;
  const totalExibidoAgora = ofertasVisiveis.length;
  const haMaisOfertas = totalExibidoAgora < totalFiltrado;

  function handleVerMais() {
    setLimiteVisivel((prev) => prev + ITENS_POR_PAGINA);
  }

  function limparFiltros() {
    setCategoriaSelecionada("todas");
    setFornecedorSelecionado("todos");
    setBuscaTitulo("");
    setOrdenacao("mais_recentes");
    setLimiteVisivel(ITENS_POR_PAGINA);
  }

  function abrirVideoDaOferta(ofertaId: string) {
    const idx = ofertasFiltradasEOrdenadas.findIndex((o) => o.id === ofertaId);
    if (idx >= 0) {
      setIndiceModalVideo(idx);
    }
  }

  function irParaVideoAnterior() {
    setIndiceModalVideo((prev) => {
      if (prev === null || ofertasFiltradasEOrdenadas.length === 0) return null;
      return (
        (prev - 1 + ofertasFiltradasEOrdenadas.length) %
        ofertasFiltradasEOrdenadas.length
      );
    });
  }

  function irParaProximoVideo() {
    setIndiceModalVideo((prev) => {
      if (prev === null || ofertasFiltradasEOrdenadas.length === 0) return null;
      return (prev + 1) % ofertasFiltradasEOrdenadas.length;
    });
  }

  const haFiltroAtivo =
    categoriaSelecionada !== "todas" ||
    fornecedorSelecionado !== "todos" ||
    buscaTitulo.trim() !== "" ||
    ordenacao !== "mais_recentes";

  const rotuloContagem =
    totalExibidoAgora === 1
      ? "1 oferta exibida"
      : `${totalExibidoAgora} ofertas exibidas`;

  return (
    <section className="min-h-screen bg-black text-white px-4 py-8 max-w-6xl mx-auto space-y-8">
      <header className="space-y-4">
        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            J4UMarketPlace
          </h1>
          <p className="text-sm sm:text-base text-zinc-300">
            Navegue por categoria ou parceiro, veja o produto em alta definição
            por inteiro e toque em{" "}
            <span className="text-white font-semibold">Ver em vídeo</span> para
            assistir na demonstração interativa.
          </p>
        </div>

        {!carregando && (
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 rounded-xl bg-zinc-950 border border-zinc-800">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-xs uppercase tracking-wider text-zinc-400">
                Filtros ativos:
              </span>

              {categoriaAtivaObjeto ? (
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-500 text-black">
                  {categoriaAtivaObjeto.icone} {categoriaAtivaObjeto.nome}
                </span>
              ) : (
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-zinc-900 text-zinc-200 border border-zinc-700">
                  Todas as categorias
                </span>
              )}

              {fornecedorAtivoObjeto ? (
                <span
                  className="text-xs font-bold px-3 py-1 rounded-full text-black"
                  style={{
                    backgroundColor:
                      fornecedorAtivoObjeto.cor_badge || "#38BDF8",
                  }}
                >
                  {fornecedorAtivoObjeto.nome}
                </span>
              ) : (
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-white text-black">
                  Todos os fornecedores
                </span>
              )}

              {buscaTitulo.trim() !== "" && (
                <span className="text-xs text-zinc-300 bg-zinc-900 border border-zinc-700 px-2.5 py-1 rounded-full">
                  Busca: &ldquo;{buscaTitulo.trim()}&rdquo;
                </span>
              )}
            </div>

            <p className="text-sm font-semibold text-white" aria-live="polite">
              {rotuloContagem}{" "}
              <span className="text-zinc-400 font-normal">
                (de {totalFiltrado} encontradas)
              </span>
            </p>
          </div>
        )}
      </header>

      <div className="space-y-4">
        <div className="flex flex-col md:flex-row gap-3">
          <input
            type="search"
            value={buscaTitulo}
            onChange={(e) => setBuscaTitulo(e.target.value)}
            placeholder="Buscar oferta pelo título..."
            aria-label="Buscar oferta pelo título"
            className="flex-1 px-4 py-2.5 rounded-lg bg-zinc-950 border border-zinc-700 text-white placeholder-zinc-500 focus:outline-none focus:border-blue-500"
          />

          <select
            value={ordenacao}
            onChange={(e) =>
              setOrdenacao(e.target.value as TipoOrdenacaoOferta)
            }
            aria-label="Ordenar ofertas"
            className="px-4 py-2.5 rounded-lg bg-zinc-950 border border-zinc-700 text-white focus:outline-none focus:border-blue-500 md:w-56"
          >
            <option value="mais_recentes">Mais recentes</option>
            <option value="menor_preco">Menor preço</option>
            <option value="maior_preco">Maior preço</option>
          </select>

          {haFiltroAtivo && (
            <button
              type="button"
              onClick={limparFiltros}
              className="px-4 py-2.5 rounded-lg border border-zinc-700 bg-zinc-950 text-zinc-200 hover:bg-zinc-900 text-sm font-semibold"
            >
              Limpar filtros
            </button>
          )}
        </div>

        {categorias.length > 0 && (
          <div className="space-y-1.5">
            <span className="block text-xs uppercase tracking-wider text-zinc-400">
              Categorias
            </span>
            <div
              className="flex flex-wrap items-center gap-2"
              role="group"
              aria-label="Filtrar por categoria"
            >
              <button
                type="button"
                onClick={() => setCategoriaSelecionada("todas")}
                className={`px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold border transition ${
                  categoriaSelecionada === "todas"
                    ? "bg-emerald-500 text-black border-emerald-400"
                    : "bg-zinc-950 text-zinc-200 border-zinc-700 hover:border-zinc-500"
                }`}
              >
                Todas ({ofertas.length})
              </button>

              {categorias.map((categoria) => {
                const ativa = categoriaSelecionada === categoria.id;
                const totalDaCategoria = ofertas.filter(
                  (o) => o.categoria_id === categoria.id
                ).length;

                return (
                  <button
                    key={categoria.id}
                    type="button"
                    onClick={() => setCategoriaSelecionada(categoria.id)}
                    className={`px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold border transition flex items-center gap-1.5 ${
                      ativa
                        ? "bg-emerald-500 text-black border-emerald-400"
                        : "bg-zinc-950 text-zinc-200 border-zinc-700 hover:border-zinc-500"
                    }`}
                  >
                    <span>{categoria.icone}</span>
                    <span>{categoria.nome}</span>
                    <span className="opacity-75">({totalDaCategoria})</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div className="space-y-1.5">
          <span className="block text-xs uppercase tracking-wider text-zinc-400">
            Fornecedores
          </span>
          <div
            className="flex flex-wrap items-center gap-2"
            role="group"
            aria-label="Filtrar por fornecedor"
          >
            <button
              type="button"
              onClick={() => setFornecedorSelecionado("todos")}
              className={`px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold border transition ${
                fornecedorSelecionado === "todos"
                  ? "bg-white text-black border-white"
                  : "bg-zinc-950 text-zinc-200 border-zinc-700 hover:border-zinc-500"
              }`}
            >
              Todos ({ofertas.length})
            </button>

            {fornecedores.map((fornecedor) => {
              const ativo = fornecedorSelecionado === fornecedor.id;
              const totalDoFornecedor = ofertas.filter(
                (o) => o.fornecedor_id === fornecedor.id
              ).length;

              return (
                <button
                  key={fornecedor.id}
                  type="button"
                  onClick={() => setFornecedorSelecionado(fornecedor.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold border transition ${
                    ativo
                      ? "bg-blue-600 text-white border-blue-400"
                      : "bg-zinc-950 text-zinc-200 border-zinc-700 hover:border-zinc-500"
                  }`}
                >
                  {fornecedor.nome} ({totalDoFornecedor})
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {erro && <p className="text-sm text-red-400">{erro}</p>}

      {carregando ? (
        <p className="text-sm text-zinc-400">Carregando vitrine...</p>
      ) : ofertasVisiveis.length === 0 ? (
        <div className="p-8 rounded-xl bg-zinc-950 border border-zinc-800 text-center space-y-3">
          <p className="text-zinc-300">
            Nenhuma oferta encontrada para a combinação de categoria, fornecedor
            e busca.
          </p>
          {haFiltroAtivo && (
            <button
              type="button"
              onClick={limparFiltros}
              className="px-4 py-2 rounded bg-white text-black text-sm font-semibold"
            >
              Limpar filtros
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {ofertasVisiveis.map((oferta) => {
              const temImagem = Boolean(
                oferta.imagem_url && oferta.imagem_url.trim().length > 0
              );

              return (
                <article
                  key={oferta.id}
                  className="group rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-zinc-600 overflow-hidden flex flex-col justify-between transition"
                >
                  <div>
                    <div className="relative h-72 w-full bg-white flex items-center justify-center p-4 border-b border-zinc-800 overflow-hidden">
                      {temImagem ? (
                        <img
                          src={oferta.imagem_url ?? ""}
                          alt={oferta.titulo}
                          loading="lazy"
                          className="max-h-full max-w-full w-auto h-auto object-contain transition-transform duration-300 group-hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full bg-zinc-900 rounded-xl flex flex-col items-center justify-center text-center p-4 space-y-2">
                          <span className="text-2xl">📦</span>
                          <p className="text-xs text-zinc-400">
                            Foto em atualização — assista à demonstração em
                            vídeo
                          </p>
                        </div>
                      )}

                      <div className="absolute top-3 left-3 flex flex-wrap items-center gap-1.5">
                        {oferta.fornecedor ? (
                          <span
                            className="text-xs font-extrabold px-3 py-1 rounded-full text-black shadow"
                            style={{
                              backgroundColor:
                                oferta.fornecedor.cor_badge || "#38BDF8",
                            }}
                          >
                            {oferta.fornecedor.nome}
                          </span>
                        ) : (
                          <span className="text-xs font-bold px-3 py-1 rounded-full bg-zinc-900 text-white shadow">
                            Parceiro
                          </span>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => abrirVideoDaOferta(oferta.id)}
                        className="absolute bottom-3 right-3 px-3.5 py-2 rounded-full bg-black/90 hover:bg-blue-600 text-white border border-white/20 text-xs font-bold shadow-lg flex items-center gap-1.5 transition"
                      >
                        <span>📱</span>
                        <span>Ver em vídeo</span>
                      </button>
                    </div>

                    <div className="p-5 space-y-2.5">
                      {oferta.categoria && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-md bg-zinc-900 border border-zinc-800 text-zinc-300">
                          <span>{oferta.categoria.icone}</span>
                          <span>{oferta.categoria.nome}</span>
                        </span>
                      )}

                      <h2 className="text-base sm:text-lg font-bold text-white leading-snug">
                        {oferta.titulo}
                      </h2>

                      <p className="text-2xl font-extrabold text-emerald-400">
                        R$ {Number(oferta.preco).toFixed(2)}
                      </p>
                    </div>
                  </div>

                  <div className="p-5 pt-0 grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => abrirVideoDaOferta(oferta.id)}
                      className="py-2.5 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 font-semibold text-xs sm:text-sm text-white flex items-center justify-center gap-1.5 transition"
                    >
                      <span>▶</span>
                      <span>Ver em vídeo</span>
                    </button>

                    <a
                      href={oferta.url_afiliado}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 font-semibold text-xs sm:text-sm text-white flex items-center justify-center transition"
                    >
                      Ver oferta
                    </a>
                  </div>
                </article>
              );
            })}
          </div>

          {haMaisOfertas && (
            <div className="flex flex-col items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleVerMais}
                className="px-6 py-3 rounded-lg bg-white hover:bg-zinc-200 text-black font-semibold text-sm transition"
              >
                Ver mais ofertas ({totalFiltrado - totalExibidoAgora} restantes)
              </button>
            </div>
          )}
        </>
      )}

      <SmartphoneVideoModal
        oferta={ofertaSelecionadaVideo}
        onFechar={() => setIndiceModalVideo(null)}
        onAnterior={irParaVideoAnterior}
        onProxima={irParaProximoVideo}
        indiceAtual={indiceModalVideo ?? 0}
        totalOfertas={ofertasFiltradasEOrdenadas.length}
      />
    </section>
  );
}
