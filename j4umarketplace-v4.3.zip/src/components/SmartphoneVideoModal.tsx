"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Oferta } from "@/types/marketplace";

interface SmartphoneVideoModalProps {
  oferta: Oferta | null;
  onFechar: () => void;
  onAnterior?: () => void;
  onProxima?: () => void;
  indiceAtual?: number;
  totalOfertas?: number;
}

const LINHAS_TECLADO: string[][] = [
  ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
  ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
  ["Z", "X", "C", "V", "B", "N", "M", "!", "?"],
];

function formatarTempo(segundos: number): string {
  if (!Number.isFinite(segundos) || segundos < 0) return "0:00";
  const min = Math.floor(segundos / 60);
  const seg = Math.floor(segundos % 60);
  return `${min}:${seg.toString().padStart(2, "0")}`;
}

export function SmartphoneVideoModal({
  oferta,
  onFechar,
  onAnterior,
  onProxima,
  indiceAtual = 0,
  totalOfertas = 1,
}: SmartphoneVideoModalProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const [tocando, setTocando] = useState(true);
  const [mutado, setMutado] = useState(false);
  const [mostrarLegendas, setMostrarLegendas] = useState(true);
  const [textoLegenda, setTextoLegenda] = useState("");
  const [tecladoAberto, setTecladoAberto] = useState(false);
  const [caixaAlta, setCaixaAlta] = useState(true);
  const [tempoAtual, setTempoAtual] = useState(0);
  const [duracao, setDuracao] = useState(0);
  const [erroVideo, setErroVideo] = useState(false);

  useEffect(() => {
    if (!oferta) return;
    const legendaInicial =
      oferta.legenda_video?.trim() ||
      `${oferta.titulo} — R$ ${Number(oferta.preco).toFixed(2)}`;
    setTextoLegenda(legendaInicial);
    setMostrarLegendas(true);
    setTecladoAberto(false);
    setErroVideo(false);
    setTempoAtual(0);
    setDuracao(0);
    setTocando(true);
  }, [oferta]);

  useEffect(() => {
    const vid = videoRef.current;
    if (!vid || !oferta) return;
    vid.muted = mutado;
  }, [mutado, oferta]);

  useEffect(() => {
    const vid = videoRef.current;
    if (!vid || !oferta) return;
    vid
      .play()
      .then(() => setTocando(true))
      .catch(() => {
        vid.muted = true;
        setMutado(true);
        vid
          .play()
          .then(() => setTocando(true))
          .catch(() => setTocando(false));
      });
  }, [oferta]);

  const alternarPlayPause = useCallback(() => {
    const vid = videoRef.current;
    if (!vid) return;
    if (vid.paused) {
      vid
        .play()
        .then(() => setTocando(true))
        .catch(() => setTocando(false));
    } else {
      vid.pause();
      setTocando(false);
    }
  }, []);

  const alternarMudo = useCallback(() => {
    const vid = videoRef.current;
    if (!vid) return;
    const proximo = !mutado;
    vid.muted = proximo;
    setMutado(proximo);
  }, [mutado]);

  useEffect(() => {
    if (!oferta) return;
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        onFechar();
      } else if (!tecladoAberto && e.key === " ") {
        e.preventDefault();
        alternarPlayPause();
      } else if (!tecladoAberto && (e.key === "m" || e.key === "M")) {
        alternarMudo();
      } else if (!tecladoAberto && e.key === "ArrowRight" && onProxima) {
        onProxima();
      } else if (!tecladoAberto && e.key === "ArrowLeft" && onAnterior) {
        onAnterior();
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    oferta,
    onFechar,
    tecladoAberto,
    alternarPlayPause,
    alternarMudo,
    onProxima,
    onAnterior,
  ]);

  const legendaPadraoOferta = useMemo(() => {
    if (!oferta) return "";
    return (
      oferta.legenda_video?.trim() ||
      `${oferta.titulo} — R$ ${Number(oferta.preco).toFixed(2)}`
    );
  }, [oferta]);

  if (!oferta) return null;

  const caminhoVideo = `/video/${oferta.video_arquivo || "video0001.mp4"}`;
  const progressoPercentual =
    duracao > 0 ? Math.min(100, (tempoAtual / duracao) * 100) : 0;

  function digitarCaractere(char: string) {
    const letra = caixaAlta ? char.toUpperCase() : char.toLowerCase();
    setTextoLegenda((prev) => prev + letra);
    setMostrarLegendas(true);
    if (caixaAlta && /[A-Z]/.test(char)) {
      setCaixaAlta(false);
    }
  }

  function apagarCaractere() {
    setTextoLegenda((prev) => prev.slice(0, -1));
  }

  function limparLegenda() {
    setTextoLegenda("");
  }

  function restaurarLegenda() {
    setTextoLegenda(legendaPadraoOferta);
    setMostrarLegendas(true);
    setCaixaAlta(true);
  }

  function handleSeek(e: React.ChangeEvent<HTMLInputElement>) {
    const vid = videoRef.current;
    const novoTempo = Number(e.target.value);
    setTempoAtual(novoTempo);
    if (vid && Number.isFinite(novoTempo)) {
      vid.currentTime = novoTempo;
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label={`Player em vídeo: ${oferta.titulo}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onFechar();
      }}
    >
      <button
        type="button"
        onClick={onFechar}
        aria-label="Fechar player do celular"
        className="fixed top-4 right-4 z-50 px-3.5 py-2 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-bold text-white shadow-lg transition"
      >
        ✕ Fechar
      </button>

      {totalOfertas > 1 && onAnterior && (
        <button
          type="button"
          onClick={onAnterior}
          aria-label="Oferta anterior"
          className="hidden md:flex items-center justify-center w-11 h-11 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white mr-5 transition"
        >
          ‹
        </button>
      )}

      <div className="relative w-full max-w-[392px] rounded-[46px] bg-gradient-to-b from-zinc-800 via-zinc-900 to-zinc-950 p-[11px] shadow-[0_0_80px_rgba(37,99,235,0.28)] border border-zinc-700/80 my-auto">
        <button
          type="button"
          onClick={alternarMudo}
          title="Volume / Mudo"
          className="hidden sm:block absolute -left-[4px] top-28 w-[3px] h-10 bg-zinc-600 rounded-l"
        />
        <button
          type="button"
          onClick={alternarPlayPause}
          title="Play / Pause"
          className="hidden sm:block absolute -right-[4px] top-32 w-[3px] h-14 bg-zinc-600 rounded-r"
        />

        <div className="relative w-full rounded-[36px] bg-black overflow-hidden border border-zinc-800 flex flex-col">
          <div className="flex items-center justify-between px-5 pt-2.5 pb-2 bg-black text-[11px] font-semibold text-zinc-300 select-none">
            <span>J4U • LIVE</span>
            <div className="w-24 h-5 rounded-full bg-zinc-950 border border-zinc-800 flex items-center justify-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[10px] text-zinc-400">
                {indiceAtual + 1}/{totalOfertas}
              </span>
            </div>
            <span>5G 100%</span>
          </div>

          <div
            className={`relative w-full bg-zinc-950 transition-all duration-200 ${
              tecladoAberto ? "h-[245px]" : "h-[430px]"
            }`}
          >
            {erroVideo ? (
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center space-y-2 bg-zinc-950">
                <p className="text-sm font-bold text-red-400">
                  Vídeo não encontrado em public{caminhoVideo}
                </p>
                <p className="text-xs text-zinc-400">
                  Verifique se o arquivo{" "}
                  <code className="text-zinc-200">{oferta.video_arquivo}</code>{" "}
                  está salvo na pasta{" "}
                  <code className="text-zinc-200">public/video/</code>.
                </p>
              </div>
            ) : (
              <video
                key={caminhoVideo}
                ref={videoRef}
                src={caminhoVideo}
                playsInline
                loop
                preload="auto"
                onClick={alternarPlayPause}
                onTimeUpdate={(e) => setTempoAtual(e.currentTarget.currentTime)}
                onLoadedMetadata={(e) => setDuracao(e.currentTarget.duration)}
                onPlay={() => setTocando(true)}
                onPause={() => setTocando(false)}
                onError={() => setErroVideo(true)}
                className="w-full h-full object-contain bg-black cursor-pointer"
              />
            )}

            <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 pointer-events-none">
              <div className="flex flex-wrap items-center gap-1.5 pointer-events-auto">
                <span
                  className="text-[11px] font-extrabold px-2.5 py-1 rounded-full text-black shadow"
                  style={{
                    backgroundColor: oferta.fornecedor?.cor_badge || "#38BDF8",
                  }}
                >
                  {oferta.fornecedor?.nome || "Oferta J4U"}
                </span>

                {oferta.categoria && (
                  <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-black/80 text-zinc-200 border border-zinc-700">
                    {oferta.categoria.icone} {oferta.categoria.nome}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 pointer-events-auto shrink-0">
                {totalOfertas > 1 && onAnterior && (
                  <button
                    type="button"
                    onClick={onAnterior}
                    className="px-2.5 py-1 rounded-full bg-black/75 border border-zinc-700 text-[11px] text-white hover:bg-zinc-900"
                  >
                    ‹ Ant
                  </button>
                )}
                {totalOfertas > 1 && onProxima && (
                  <button
                    type="button"
                    onClick={onProxima}
                    className="px-2.5 py-1 rounded-full bg-black/75 border border-zinc-700 text-[11px] text-white hover:bg-zinc-900"
                  >
                    Próx ›
                  </button>
                )}
              </div>
            </div>

            {!tocando && !erroVideo && (
              <button
                type="button"
                onClick={alternarPlayPause}
                aria-label="Retomar reprodução"
                className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-black/75 border border-white/30 text-white flex items-center justify-center text-xl shadow-lg hover:scale-105 transition"
              >
                ▶
              </button>
            )}

            {mostrarLegendas && textoLegenda.trim() !== "" && (
              <div className="absolute bottom-3 left-3 right-3 flex justify-center pointer-events-none">
                <div className="max-w-[94%] px-3.5 py-2 rounded-xl bg-black/85 border border-white/15 text-center shadow-lg">
                  <p className="text-xs sm:text-[13px] font-semibold leading-snug text-white drop-shadow">
                    {textoLegenda}
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="px-4 pt-2 pb-1 bg-zinc-950 border-t border-zinc-900 space-y-1">
            <input
              type="range"
              min={0}
              max={duracao || 100}
              step={0.1}
              value={tempoAtual}
              onChange={handleSeek}
              aria-label="Progresso do vídeo"
              className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex items-center justify-between text-[10px] text-zinc-400 font-mono">
              <span>{formatarTempo(tempoAtual)}</span>
              <span>{Math.round(progressoPercentual)}%</span>
              <span>{formatarTempo(duracao)}</span>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-1.5 px-3 py-2 bg-zinc-950 border-t border-zinc-900">
            <button
              type="button"
              onClick={alternarPlayPause}
              className={`py-2 px-1.5 rounded-xl text-[11px] font-bold border transition flex flex-col items-center gap-0.5 ${
                tocando
                  ? "bg-zinc-900 border-zinc-700 text-white hover:bg-zinc-800"
                  : "bg-blue-600 border-blue-400 text-white"
              }`}
            >
              <span>{tocando ? "⏸" : "▶"}</span>
              <span>{tocando ? "Pausar" : "Tocar"}</span>
            </button>

            <button
              type="button"
              onClick={alternarMudo}
              className={`py-2 px-1.5 rounded-xl text-[11px] font-bold border transition flex flex-col items-center gap-0.5 ${
                mutado
                  ? "bg-amber-950/80 border-amber-600 text-amber-300"
                  : "bg-zinc-900 border-zinc-700 text-white hover:bg-zinc-800"
              }`}
            >
              <span>{mutado ? "🔇" : "🔊"}</span>
              <span>{mutado ? "Mutado" : "Som"}</span>
            </button>

            <button
              type="button"
              onClick={() => setMostrarLegendas((prev) => !prev)}
              className={`py-2 px-1.5 rounded-xl text-[11px] font-bold border transition flex flex-col items-center gap-0.5 ${
                mostrarLegendas
                  ? "bg-emerald-950/80 border-emerald-600 text-emerald-300"
                  : "bg-zinc-900 border-zinc-700 text-zinc-400 hover:bg-zinc-800"
              }`}
            >
              <span>CC</span>
              <span>{mostrarLegendas ? "Omitir" : "Legenda"}</span>
            </button>

            <button
              type="button"
              onClick={() => setTecladoAberto((prev) => !prev)}
              className={`py-2 px-1.5 rounded-xl text-[11px] font-bold border transition flex flex-col items-center gap-0.5 ${
                tecladoAberto
                  ? "bg-blue-600 border-blue-400 text-white"
                  : "bg-zinc-900 border-zinc-700 text-white hover:bg-zinc-800"
              }`}
            >
              <span>⌨</span>
              <span>{tecladoAberto ? "Fechar" : "Editar CC"}</span>
            </button>
          </div>

          {tecladoAberto ? (
            <div className="bg-zinc-900 border-t border-zinc-800 p-2.5 space-y-2 select-none">
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={textoLegenda}
                  onChange={(e) => {
                    setTextoLegenda(e.target.value);
                    setMostrarLegendas(true);
                  }}
                  placeholder="Digite ou edite a legenda do vídeo..."
                  className="flex-1 px-2.5 py-1.5 rounded-lg bg-black border border-zinc-700 text-xs text-white focus:outline-none focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={limparLegenda}
                  title="Remover toda a legenda"
                  className="px-2 py-1.5 rounded-lg bg-red-950 border border-red-800 text-[11px] font-bold text-red-300 hover:bg-red-900"
                >
                  Remover
                </button>
                <button
                  type="button"
                  onClick={restaurarLegenda}
                  title="Restaurar legenda original"
                  className="px-2 py-1.5 rounded-lg bg-zinc-800 border border-zinc-700 text-[11px] font-bold text-zinc-200 hover:bg-zinc-700"
                >
                  Reset
                </button>
              </div>

              <div className="space-y-1">
                {LINHAS_TECLADO.map((linha, idxLinha) => (
                  <div key={idxLinha} className="flex justify-center gap-1">
                    {idxLinha === 2 && (
                      <button
                        type="button"
                        onClick={() => setCaixaAlta((prev) => !prev)}
                        className={`px-2 py-1.5 rounded-md text-[11px] font-bold ${
                          caixaAlta
                            ? "bg-blue-600 text-white"
                            : "bg-zinc-800 text-zinc-300"
                        }`}
                      >
                        ⇧
                      </button>
                    )}

                    {linha.map((tecla) => (
                      <button
                        key={tecla}
                        type="button"
                        onClick={() => digitarCaractere(tecla)}
                        className="flex-1 max-w-[31px] py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 active:bg-blue-600 text-xs font-semibold text-white shadow-sm"
                      >
                        {caixaAlta ? tecla : tecla.toLowerCase()}
                      </button>
                    ))}

                    {idxLinha === 2 && (
                      <button
                        type="button"
                        onClick={apagarCaractere}
                        aria-label="Apagar caractere"
                        className="px-2.5 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white"
                      >
                        ⌫
                      </button>
                    )}
                  </div>
                ))}

                <div className="flex items-center gap-1 pt-0.5">
                  <button
                    type="button"
                    onClick={() => setMostrarLegendas((prev) => !prev)}
                    className="px-2.5 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-[11px] font-bold text-emerald-300"
                  >
                    {mostrarLegendas ? "Omitir CC" : "Exibir CC"}
                  </button>

                  <button
                    type="button"
                    onClick={() => digitarCaractere(" ")}
                    className="flex-1 py-1.5 rounded-md bg-zinc-800 hover:bg-zinc-700 text-[11px] font-semibold text-zinc-200"
                  >
                    Espaço
                  </button>

                  <button
                    type="button"
                    onClick={() => setTecladoAberto(false)}
                    className="px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-500 text-[11px] font-bold text-white"
                  >
                    OK
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="px-4 py-3 bg-black border-t border-zinc-900 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs font-semibold text-zinc-200 line-clamp-1">
                  {oferta.titulo}
                </p>
                <span className="text-base font-extrabold text-emerald-400 shrink-0">
                  R$ {Number(oferta.preco).toFixed(2)}
                </span>
              </div>

              <a
                href={oferta.url_afiliado}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full text-center py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 font-bold text-sm text-white transition"
              >
                Aproveitar oferta agora →
              </a>
            </div>
          )}

          <div className="py-2 bg-black flex justify-center">
            <button
              type="button"
              onClick={onFechar}
              title="Voltar para a vitrine"
              className="w-28 h-1 rounded-full bg-zinc-700 hover:bg-zinc-500 transition"
            />
          </div>
        </div>
      </div>

      {totalOfertas > 1 && onProxima && (
        <button
          type="button"
          onClick={onProxima}
          aria-label="Próxima oferta"
          className="hidden md:flex items-center justify-center w-11 h-11 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white ml-5 transition"
        >
          ›
        </button>
      )}
    </div>
  );
}
